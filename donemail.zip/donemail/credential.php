<?php 
	/*Update credentials*/
	define('EMAIL', '*******@gmail.com');
	define('PASS', 'password_******');
 ?>